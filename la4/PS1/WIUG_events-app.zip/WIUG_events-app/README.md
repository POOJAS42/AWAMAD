# cometchat-events-app
This events application is a clone of the youtube live event, but we used the cometchat API to utilize the chat aspect and authentication aspect of our application
