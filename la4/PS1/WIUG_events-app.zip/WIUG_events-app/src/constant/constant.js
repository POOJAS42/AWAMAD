export const AUTH_KEY = '9d323aec801c0a3c0de9f44df025e7272370903a'
export const APPID = "2816364baa209f1"
export const API_REGION = 'us'